/*
 * CTerm.cpp
 *
 *  Created on: Apr 4, 2017
 *      Author: zeqingzhang
 */

#include "CTerm.h"
#include <memory>
using namespace std;
using namespace hw10;

CTerm::CTerm(){

}

CTerm::~CTerm(){

}

shared_ptr<BTerm> CTerm::getUpper() const noexcept {
	return upper_.lock();
}

void CTerm::setUpper(shared_ptr<BTerm> upper) {

	// If the parameter is empty, then throw an exception

	if(!upper) {
		throw domain_error("the parameter cannot be empty!");
	}

	if(upper_.expired()){
		if(isParent(upper)){
			upper_ = upper;
			return;
		}
		throw domain_error("Attempt to set the upper link of a term to a term named "+
								upper->getName() + " that is not an ancestor");
	}
}

bool CTerm::isParent(shared_ptr<Term> upper){
	if(!upper){
		return false;
	}

	return upper == shared_from_this() || isParent(upper->getLeft()) || isParent(upper->getRight());
}



void CTerm::traverse(function<void(shared_ptr<Term> term)> preAction) {
	preAction(shared_from_this());
}

void CTerm::print(ostream& out) const noexcept {
	if(getUpper()){
		out << getUpper()->getName();
	}

}


