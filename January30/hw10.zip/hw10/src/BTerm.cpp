/*
 * BTerm.cpp
 *
 *  Created on: Apr 4, 2017
 *      Author: zeqingzhang
 */



#include "BTerm.h"
#include <set>
#include <memory>
#include <iostream>
#include <string>

using namespace hw10;
using namespace std;

BTerm::BTerm(const string& name, shared_ptr<Term> left, shared_ptr<Term> right) :
		left_(left), right_(right),name_(name){

};


BTerm::~BTerm(){

}

shared_ptr<Term> BTerm::getLeft() const noexcept{
	return left_;
}


shared_ptr<Term> BTerm::getRight() const noexcept{
	return right_;
}

string BTerm::getName() const noexcept{
	return name_;
}

void BTerm::traverse(std::function<void(std::shared_ptr<Term> term)> preAction){
	preAction(shared_from_this());
	shared_from_this()->getLeft()->traverse(preAction);
	shared_from_this()->getRight()->traverse(preAction);
}

void BTerm::print(ostream& out) const noexcept{
	out << "[";
	out << getName() << ":";
	right_->print(out);
	out << "]";
	out << "(";
	left_->print(out);
	out << ")";
}







